<x-layouts.admin title="Dashboard" section-title="Dashboard">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus dolorum nulla aperiam sed id nobis ullam magnam veniam quibusdam, soluta, deleniti, autem doloribus rem nesciunt reiciendis perferendis corrupti cupiditate ratione?
</x-layouts.admin>