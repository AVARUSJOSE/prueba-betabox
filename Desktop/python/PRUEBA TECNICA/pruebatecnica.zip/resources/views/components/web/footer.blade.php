<!-- footer begin -->

<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2>
                    {{ env('App_name') }}
                </h2>
                <p>
                    &copy; Copyright 2022 - {{ env('APP_NAME') }} hecho por <a
                        href="mailto:joseaizaguirrep@gmail.com
                    ">Jose Alberto</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- footer close -->
