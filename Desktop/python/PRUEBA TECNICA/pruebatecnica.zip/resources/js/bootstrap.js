import Axios from 'axios';
import Alpine from 'alpinejs';

window.axios = Axios;
window.Alpine = Alpine;
 
Alpine.start();