<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.web','data' => []]); ?>
<?php $component->withName('layouts.web'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div
        style="min-height: 60vh; background: url(<?php echo e($post->imagePath); ?>); display: flex; align-items: center; justify-content: center; background-size: 100% 100%; background-position: center;">
        <div class="text-center">
            <h1 class="text-white">
                <?php echo e($post->title); ?>

            </h1>
        </div>
    </div>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <p class="text-primary">
                    <b>Creado Por:</b>
                </p>
                <div class="d-flex align-items-center">
                    <img src="<?php echo e($post->user->imagePath); ?>" style="height: 40px; width: 40px; border-radius: 100%;"
                        alt="">
                    <p class="text-primary" style="margin-left: 5px; margin-bottom: 0;">
                        <?php echo e($post->user->name); ?>

                    </p>
                </div>
            </div>
            <div class="col-md-3">
                <p class="text-primary">
                    <b>Fecha de creación</b>
                </p>
                <?php echo e($post->created_at->format('d/m/Y H:i:s')); ?>

            </div>
            <div class="col-md-3">
                <p class="text-primary">
                    <b>Comentarios</b>
                </p>
                <?php echo e($post->comments->count()); ?> Comentarios.
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <div class="container" style="background:whitesmoke; padding: 50px; border-radius: 10px;">
        <?php echo e($post->description); ?>

    </div>
    <br>
    <br>
    <br>
    <div class="container text-center" style="background:whitesmoke; padding: 50px; border-radius: 10px;">
        <h3>
            Comentarios
        </h3>
        <ul style="max-height: 60vh; overflow-y: auto;">
            <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="mb-5" style="background:white; padding: 20px; border-radius: 10px;">
                    <div class="d-flex justify-content-between">
                        <div class="d-flex align-items-center">
                            <img src="<?php echo e($comment->user->imagePath); ?>"
                                style="height: 40px; width: 40px; border-radius: 100%;" alt="">
                            <p class="text-primary" style="margin-left: 5px; margin-bottom: 0;">
                                <?php echo e(auth()->user()->id === $comment->user_id ? 'Tú' : $comment->user->name); ?>

                            </p>
                        </div>
                        <div>
                            <?php echo e($comment->created_at->format('d/m/Y H:i:s')); ?>

                        </div>
                    </div>
                    <p class="text-start mt-3 mb-0">
                        <?php echo e($comment->message); ?>

                    </p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="my-5" style="background:white; padding: 20px; border-radius: 10px;">
                    <h4 class="text-center text-danger">
                        Este Post no contiene comentarios.
                    </h4>
                </li>
            <?php endif; ?>
            <?php if($comments->hasPages()): ?>
                <li class="d-flex align-items-center justify-content-center w-100">
                    <?php echo e($comments->links('web.pagination')); ?>

                </li>
            <?php endif; ?>
        </ul>
        <?php if(auth()->guard()->check()): ?>
            <form class="row" method="POST" action="<?php echo e(route('comments.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                <div class="input-group has-validation">
                    <div class="form-floating <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <input type="text" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message"
                            required="" value="<?php echo e(old('message')); ?>" id="message" placeholder="Escribe el mensaje"
                            required>
                        <label for="message">Mensaje</label>
                    </div>
                    <button class="input-group-text btn btn-primary">
                        Enviar
                    </button>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </form>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <div class="row align-items-center">
                <div class="col-md-12">
                    <h5>Debes iniciar sesión para poder comentar</h5>
                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(route('admin.login')); ?>" class="btn btn-primary w-100">
                        Iniciar Sesión
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="#" class="btn btn-primary w-100">
                        Resgistrarse
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <br>
    <br>
    <br>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/web/post.blade.php ENDPATH**/ ?>