<?php $attributes = $attributes->exceptProps([
    'title' => null,
]); ?>
<?php foreach (array_filter(([
    'title' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.html','data' => ['title' => $title]]); ?>
<?php $component->withName('layouts.html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <!-- CSS Files
        ================================================== -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

        <link href="<?php echo e(asset('css/sweetalert.min.css')); ?>" rel="stylesheet" type="text/css">

        <?php echo $__env->yieldPushContent('styles'); ?>
     <?php $__env->endSlot(); ?>

    <div id="wrapper">
        <?php if (isset($component)) { $__componentOriginal3b9fb8c05b2f1d9afc5d82b4975c1314287ff328 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Web\Header::class, []); ?>
<?php $component->withName('web.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b9fb8c05b2f1d9afc5d82b4975c1314287ff328)): ?>
<?php $component = $__componentOriginal3b9fb8c05b2f1d9afc5d82b4975c1314287ff328; ?>
<?php unset($__componentOriginal3b9fb8c05b2f1d9afc5d82b4975c1314287ff328); ?>
<?php endif; ?>
        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <?php echo e($slot); ?>

        </div>
        <?php if (isset($component)) { $__componentOriginald01a960181f7745b903614ff1e0d851cd7c1caad = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Web\Footer::class, []); ?>
<?php $component->withName('web.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01a960181f7745b903614ff1e0d851cd7c1caad)): ?>
<?php $component = $__componentOriginald01a960181f7745b903614ff1e0d851cd7c1caad; ?>
<?php unset($__componentOriginald01a960181f7745b903614ff1e0d851cd7c1caad); ?>
<?php endif; ?>
    </div>

     <?php $__env->slot('scripts', null, []); ?> 
        <?php echo $__env->yieldPushContent('beforeScripts'); ?>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script>

        <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

        <script>
            var title = <?php echo json_encode(session('success'), 15, 512) ?> || '';
            var message = <?php echo json_encode(session('message'), 15, 512) ?> || '';

            <?php if($success = session('success')): ?>
                swal({
                    title: title,
                    text: message,
                    type: "success",
                });
            <?php endif; ?>
        </script>

        <?php echo $__env->yieldPushContent('scripts'); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/components/layouts/web.blade.php ENDPATH**/ ?>