<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Login | <?php echo e(env('APP_NAME')); ?></title>

    <!-- vector map CSS -->
    <link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body>
    <!--Preloader-->
    <div class="preloader-it">
        <div class="la-anim-1"></div>
    </div>
    <!--/Preloader-->

    <div class="wrapper pa-0">
        <header class="sp-header">
            <div class="sp-logo-wrap pull-left">
                <a href="<?php echo e(route('home')); ?>">
                    <h1>
                        <?php echo e(env('APP_NAME')); ?>

                    </h1>
                </a>
            </div>
            <div class="clearfix"></div>
        </header>

        <!-- Main Content -->
        <div class="page-wrapper pa-0 ma-0 auth-page">
            <div class="container">
                <!-- Row -->
                <div class="table-struct full-width full-height">
                    <div class="table-cell vertical-align-middle auth-form-wrap">
                        <div class="auth-form  ml-auto mr-auto no-float card-view pt-30 pb-30">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <div class="mb-30">
                                        <h3 class="text-center txt-dark mb-10">Iniciar sesión</h3>
                                        <h6 class="text-center nonecase-font txt-grey">Ingresa tus credenciales abajo
                                        </h6>
                                    </div>
                                    <div class="form-wrap">
                                        <form action="<?php echo e(route('admin.login')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <label class="control-label mb-10" for="email">Correo
                                                    electrónico</label>
                                                <input type="email" class="form-control" required="" id="email"
                                                    name="email" placeholder="Ingrese el correo"
                                                    value="<?php echo e(old('email')); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="help-block with-errors">
                                                        <ul class="list-unstyled">
                                                            <li><?php echo e($message); ?></li>
                                                        </ul>
                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label class="pull-left control-label mb-10"
                                                    for="password">Contraseña</label>
                                                <input type="password" class="form-control" required=""
                                                    id="password" name="password" placeholder="Ingrese la contraseña">
                                            </div>
                                            <div class="form-group row" style="align-items: center; display: flex;">
                                                <div class="col-md-6">
                                                    <div class="checkbox checkbox-primary pr-10 pull-left">
                                                        <input id="rememberme" name="rememberme" type="checkbox">
                                                        <label for="rememberme"> Mantener sesión iniciada</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <a class="capitalize-font txt-orange block mb-10 pull-right font-12"
                                                        href="<?php echo e(route('admin.forgotPassword')); ?>">Olvide mi
                                                        contraseña</a>
                                                </div>
                                            </div>
                                            <div class="form-group text-center">
                                                <button type="submit"
                                                    class="btn btn-orange btn-rounded">Ingresar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /Row -->
            </div>

        </div>
        <!-- /Main Content -->

    </div>
    <!-- /#wrapper -->

    <!-- JavaScript -->

    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>

    <!-- Slimscroll JavaScript -->
    <script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>

    <!-- Init JavaScript -->
    <script src="<?php echo e(asset('js/init.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>