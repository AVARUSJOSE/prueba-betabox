<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.admin','data' => ['title' => 'Comentarios','sectionTitle' => 'Comentarios']]); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Comentarios','section-title' => 'Comentarios']); ?>
    <div class="row mt-10">
        <div class="col-md-12">            
            <div class="panel panel-default card-view">
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Comentario</th>
                                        <th>Blog</th>
                                        <th>Fecha de creación</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>                                            
                                                <?php echo e($comment->id); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('newNotes.show', $comment->newNote)); ?>" target="_blank"><?php echo e($comment->text); ?></a>                                            
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('newNotes.show', $comment->newNote)); ?>" target="_blank">
                                                    <?php echo e($comment->newNote->title); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($comment->created_at->format('d/m/Y')); ?></td>
                                            <td style="white-space: no-wrap">
                                                <a href="<?php echo e(route('admin.comments.edit', $comment)); ?>" class="btn btn-primary btn-sm btn-icon-anim btn-square"><i class="icon-pencil"></i></a>
                                                <div style="display: inline" x-data>
                                                    <form x-ref="form" action="<?php echo e(route('admin.comments.destroy', $comment)); ?>" method="POST" class="hidden">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <button type="button" class="btn btn-danger btn-sm btn-icon-anim btn-square" x-on:click="
                                                        swal({   
                                                            title: '¿Está seguro?',
                                                            text: 'No podrá revertir esta acción',
                                                            type: 'warning',
                                                            showCancelButton: true,   
                                                            confirmButtonColor: '#e6b034',
                                                            confirmButtonText: 'Si, eliminarlo!',
                                                        }, () => $refs.form.submit());
                                                    "><i class="icon-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>                        
                    </div>
                    <?php if($comments->hasPages()): ?>
                        <div class="panel-footer">
                            <?php echo e($comments->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            <?php if($success = session('success')): ?>
                swal({
                    title: <?php echo json_encode($success, 15, 512) ?>,
                    type: "success",
                });
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>