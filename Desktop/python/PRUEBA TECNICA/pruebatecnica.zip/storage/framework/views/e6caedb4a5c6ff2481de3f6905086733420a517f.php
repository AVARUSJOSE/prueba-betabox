<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.web','data' => []]); ?>
<?php $component->withName('layouts.web'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div
        style="min-height: 60vh; background: url(<?php echo e(asset('img/projects.jpg')); ?>); display: flex; align-items: center; justify-content: center;">
        <div class="text-center">
            <h1 class="text-white">
                Bienvenido al sistema de publicaciones
            </h1>
            <p class="text-white">
                Aca podras conseguir los ultimos post de los usuarios.
            </p>
        </div>
    </div>
    <br><br>
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 mb-5">
                    <div class="card position-relative" style="overflow: hidden;">

                        <div class="row">
                            <div class="col-md-12"
                                style="height: 280px; border-radius: 10px; background: url(<?php echo e($post->imagePath); ?>); background-position: center; background-size: cover;">
                            </div>
                            <div class="col-md-12 p-4">
                                <h5>
                                    <a href="<?php echo e(route('post', $post)); ?>">
                                        <?php echo e($post->title); ?>

                                    </a>
                                </h5>
                                <p>
                                    <?php echo e(Str::words($post->description, 10)); ?>

                                </p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo e($post->user->imagePath); ?>"
                                                style="height: 40px; width: 40px; border-radius: 100%;" alt="">
                                            <p class="text-primary" style="margin-left: 5px; margin-bottom: 0;">
                                                <?php echo e($post->user->name); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-md-end text-center">
                                        <a href="<?php echo e(route('post', $post)); ?>" class="btn btn-primary">
                                            Ver detalle
                                        </a>
                                        <p class="m-0">
                                            Comentarios: <?php echo e($post->comments->count()); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center col-md-12">
                    <br>
                    <br>
                    <br>
                    <h2 class="text-dark animate__animated animate__pulse animate__infinite">
                        No hemos encontrado Posts 😔
                    </h2>
                    <br>
                    <br>
                    <br>
                </div>
            <?php endif; ?>
        </div>
        <?php if($posts->hasPages()): ?>
            <div class="d-flex align-items-center justify-content-center w-100">
                <?php echo e($posts->links('web.pagination')); ?>

            </div>
        <?php endif; ?>
        <br>
        <br>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/web/home/index.blade.php ENDPATH**/ ?>