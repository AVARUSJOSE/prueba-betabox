<?php if($paginator->hasPages()): ?>
    <nav aria-label="Page navigation example">
        <ul class="pagination">
            <li class="page-item">
                <a href="<?php if($paginator->onFirstPage()): ?> javascript:void(0) <?php else: ?> <?php echo e($paginator->previousPageUrl()); ?> <?php endif; ?>"
                    class="page-link">
                    Anterior
                </a>
            </li>
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <li class="disabled">
                        <a><?php echo e($element); ?></a>
                    </li>
                <?php endif; ?>

                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li class="page-item active">
                                <a href="javascript:void(0)" class="page-link"><?php echo e($page); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="page-item">
                                <a href="<?php echo e($url); ?>" class="page-link">
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="page-item">
                <a href="<?php if($paginator->hasMorePages()): ?> <?php echo e($paginator->nextPageUrl()); ?> <?php else: ?> javascript:void(0) <?php endif; ?>"
                    class="page-link">
                    Siguiente
                </a>
            </li>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/web/pagination.blade.php ENDPATH**/ ?>