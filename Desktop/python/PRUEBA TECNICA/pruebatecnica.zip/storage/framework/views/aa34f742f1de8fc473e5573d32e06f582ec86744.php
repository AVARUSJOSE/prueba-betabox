<?php $attributes = $attributes->exceptProps([
    'title' => null,
    'sectionTitle' => null,
]); ?>
<?php foreach (array_filter(([
    'title' => null,
    'sectionTitle' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.html','data' => ['title' => $title]]); ?>
<?php $component->withName('layouts.html'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
     <?php $__env->slot('styles', null, []); ?> 
        <link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

        <!--alerts CSS -->
        <link href="<?php echo e(asset('css/sweetalert.css')); ?>" rel="stylesheet" type="text/css">

        <!-- select2 CSS -->
        <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">

        <?php echo $__env->yieldPushContent('styles'); ?>
     <?php $__env->endSlot(); ?>

    <!--Preloader-->
    <div class="preloader-it">
        <div class="la-anim-1"></div>
    </div>
    <!--/Preloader-->

    <div class="wrapper theme-2-active navbar-top-light">
        <!-- Top Menu Items -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.header','data' => []]); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- /Top Menu Items -->

        <!-- Left Sidebar Menu -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.admin.sidebar-menu','data' => []]); ?>
<?php $component->withName('admin.sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- /Left Sidebar Menu -->

        <!-- Main Content -->
        <div class="page-wrapper" style="max-width: 100%; overflow-x: auto;">
            <div class="container">
                <!-- Title -->
                <div class="row heading-bg">
                    <?php if($sectionTitle): ?>
                        <div class="col-md-12">
                            <h5 class="txt-dark"><?php echo e($sectionTitle); ?></h5>
                        </div>
                    <?php endif; ?>

                    <div class="col-md-12">
                        <?php echo e($slot); ?>

                    </div>
                    <!-- /Breadcrumb -->
                </div>
                <!-- /Title -->
            </div>
        </div>
        <!-- /Main Content -->
    </div>

     <?php $__env->slot('scripts', null, []); ?> 
        <!-- jQuery -->
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>

        <!-- Slimscroll JavaScript -->
        <script src="<?php echo e(asset('js/jquery.slimscroll.js')); ?>"></script>

        <!-- Fancy Dropdown JS -->
        <script src="<?php echo e(asset('js/dropdown-bootstrap-extended.js')); ?>"></script>





        <!-- Sweet-Alert  -->
        <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

        <!-- Select2 JavaScript -->
        <script src="<?php echo e(asset('js/select2.full.min.js')); ?>"></script>

        <!-- Init JavaScript -->
        <script src="<?php echo e(asset('js/init.js')); ?>"></script>
        

        <?php echo $__env->yieldPushContent('scriptsBeforeApp'); ?>

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

        <script>
            const renderImage = (image) => {
                return `
                    <img style="width: 100%; height: 300px;" src="${URL.createObjectURL(image)}" />
                `
            }

            $('#image-picker').change((event) => {
                const image = event.target.files[0];
                $('#render-preview').html(renderImage(image))
            })
        </script>

        <?php echo $__env->yieldPushContent('scripts'); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pruebatecnica\resources\views/components/layouts/admin.blade.php ENDPATH**/ ?>